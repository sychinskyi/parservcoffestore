from flask import Flask, request, send_file, render_template_string
import pandas as pd
import requests
import io
import threading

app = Flask(__name__)

HTML_FORM = """
<!DOCTYPE html>
<html>
<head>
    <title>Сбор кофеен СПб</title>
</head>
<body>
    <h2>Получить таблицу кофеен в Санкт-Петербурге</h2>
    <form method="post">
        API-ключ 2ГИС: <input type="text" name="apikey" required><br><br>
        <input type="submit" value="Собрать и скачать Excel">
    </form>
</body>
</html>
"""

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        key = request.form.get('apikey')
        headers = {'Accept': 'application/json'}
        base_url = 'https://catalog.api.2gis.com/3.0/items'

        params = {
            'q': 'кофейня',
            'point': '30.31413,59.93863',
            'radius': 20000,
            'fields': 'items.point,items.name,items.contact_groups,items.address_name',
            'limit': 50,
            'page': 1,
            'key': key
        }

        all_items = []
        while len(all_items) < 150:
            resp = requests.get(base_url, params=params, headers=headers)
            if resp.status_code != 200:
                return f"Ошибка API: {resp.text}"
            data = resp.json()
            items = data.get('result', {}).get('items', [])
            if not items:
                break
            all_items += items
            if not data['result'].get('has_more'):
                break
            params['page'] += 1

        records = []
        for it in all_items[:150]:
            name = it['name']
            address = it.get('address_name', '')
            phones = []
            for grp in it.get('contact_groups', []):
                for c in grp.get('contacts', []):
                    if c.get('type') == 'phone':
                        phones.append(c.get('value'))
            records.append({
                'Название': name,
                'Адрес': address,
                'Телефон': '; '.join(phones)
            })

        df = pd.DataFrame(records)
        output = io.BytesIO()
        df.to_excel(output, index=False)
        output.seek(0)

        return send_file(output, as_attachment=True, download_name='кофейни_СПб.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    return render_template_string(HTML_FORM)

def run():
    app.run(host='0.0.0.0', port=7860)

threading.Thread(target=run).start()
